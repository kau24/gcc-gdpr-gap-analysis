# Reference documents

Three published comparative analyses were used in evaluation only, and were isolated
from the inference path by the leakage guard. They are third-party copyrighted works
and are **not redistributed here**. The parsed text retained in `reference_raw.json`
exists so that the leakage-guard fingerprints are reproducible.

OneTrust DataGuidance. (2023). *Comparing privacy laws: GDPR v. Saudi Arabia's PDPL,
as amended*.
https://www.dataguidance.com/resource/comparing-privacy-laws-gdpr-v-saudi-arabias-pdpl

Research Syndicate Group. (2023). *Comparison between GCC data protection
legislation*. UK-Gulf Women in Cybersecurity Fellowship Programme, delivered by Plexal
and Protection Group International for the Foreign, Commonwealth & Development Office.
https://www.plexal.com/our-work/ukgulfwic/

White Label Consultancy. (2025). *Comparative analysis of the GDPR and selected Middle
East privacy laws*.
https://whitelabelconsultancy.com/comparative-analysis-of-the-gdpr-and-selected-middle-east-privacy-laws/

## Instrument informing the screening criterion

Article 29 Data Protection Working Party. (2018). *Adequacy referential* (WP 254
rev.01). European Commission. https://ec.europa.eu/newsroom/article29/items/614108

The transposability screening criterion follows the Referential's separation of content
principles binding on a third country from the Union's own cooperation and consistency
architecture. The document was not parsed by the pipeline; the article ranges were set
by the authors on that basis.
