#!/usr/bin/env bash
# Pre-publication checks.
set -uo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
fail=0

echo "== scanning for credentials =="
if grep -rIl --exclude-dir=.git -E 'sk-[A-Za-z0-9]{20}|tgp_v1_[A-Za-z0-9]{20}' "$REPO"; then
  echo "  FAIL: possible API key found above"; fail=1
else
  echo "  ok"
fi

echo "== scanning for third-party PDFs =="
if find "$REPO/data/reference_kb" -name '*.pdf' | grep -q .; then
  echo "  FAIL: reference PDFs present; these are not redistributable"; fail=1
else
  echo "  ok"
fi

echo "== scanning for superseded artefacts =="
if find "$REPO" \( -name '*.bak' -o -name '*.corrupt' -o -name '*.bak_delete' \) | grep -q .; then
  echo "  FAIL: backup or corrupt files present"; fail=1
else
  echo "  ok"
fi

echo "== files over 50 MB (require Git LFS) =="
find "$REPO" -type f -size +50M -not -path '*/.git/*' -printf '  %p (%sB)\n' || true

echo "== placeholder text remaining =="
grep -rn --exclude-dir=.git '\[Author names\]\|\[Journal\]' "$REPO" || echo "  none"

exit $fail
