#!/usr/bin/env bash
# Copy artefacts from the Drive run directory into this repository.
# Usage:  ./scripts/copy_from_drive.sh /path/to/EXP-1

set -euo pipefail
SRC="${1:?usage: copy_from_drive.sh /path/to/EXP-1}"
RUN="$SRC/Run_Results_Final"
REPO="$(cd "$(dirname "$0")/.." && pwd)"

echo "source: $SRC"
echo "target: $REPO"

cp -v "$SRC/Code/"*.ipynb                       "$REPO/notebooks/"                 || true
cp -v "$SRC/Dataset/ALL_Annt-26.xlsx"           "$REPO/data/corpus/"               || true

cp -v "$RUN/01_corpus/"*                        "$REPO/data/corpus/"               || true
cp -v "$RUN/02_requirement_units/"*             "$REPO/data/instrument/"           || true
cp -v "$RUN/03_reference_kb/"*.json*            "$REPO/data/reference_kb/"         || true
cp -v "$RUN/04_index/"*                         "$REPO/data/index/"                || true
cp -v "$RUN/05_traces/llm_calls.jsonl"          "$REPO/results/traces/"            || true
cp -v "$RUN/06_records/"*                       "$REPO/results/records/"           || true
cp -v "$RUN/07_perturbations/"*                 "$REPO/results/perturbations/"     || true
cp -v "$RUN/08_ablation/"*                      "$REPO/results/ablation/"          || true
cp -v "$RUN/09_metrics/"*                       "$REPO/results/metrics/"           || true
cp -v "$RUN/00_manifest/"*                      "$REPO/results/metrics/"           || true
cp -v "$RUN/10_figures/"*                       "$REPO/figures/"                   || true

# remove artefacts that must not be published
find "$REPO" -name '*.bak' -delete
find "$REPO" -name '*.bak_delete' -delete
find "$REPO" -name '*.corrupt' -delete

echo
echo "done. Verify before committing:"
echo "  grep -rIl 'sk-\|tgp_' $REPO || echo '  no API keys found'"
