# Figures

Each figure is provided as PNG at 400 dpi and as vector PDF.

| File | Content |
|---|---|
| `D1_architecture` | System architecture and control flow |
| `D2_evaluation_map` | Evaluation protocol, by what each method establishes |
| `D3_leakage_control` | Leakage-control design |
| `D4_wp254_adequacy` | Adequacy requirements from WP 254 rev.01 |
| `F1_gap_profile_heatmap` | Gap profile by jurisdiction |
| `F2_gap_composition` | Composition of gap types |
| `F3_mutation_recovery` | Recovery on constructed oracles |
| `F4_confusion_matrix` | Required versus predicted, oracle set |
| `F5_metamorphic` | Invariance pass rates |
| `F6_ablation` | Recovery and cost by configuration |
| `F7_retrieval_sufficiency` | Candidate novelty by expansion round |
| `F8_risk_coverage` | Selective prediction |
| `F9_reliability` | Label reliability |

Figures D2, D3 and F1 through F9 are produced by the notebook and copied by
`scripts/copy_from_drive.sh`. D1 and D4 are drawn separately and are committed here.
