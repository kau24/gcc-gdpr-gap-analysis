# Manuscript sections

Working drafts of the paper, by section.

| File | Section |
|---|---|
| `introduction.docx` | 1 Introduction, with objectives and contributions |
| `related_work.docx` | 2 Related work |
| `related_work_ai_nlp.docx` | 2.1 AI and NLP foundations, condensed |
| `methods_dataset_section.docx` | 3.1 Dataset preparation and processing |
| `results_section.docx` | 4 Results |
| `gap_profile_table.docx` | Table 5, standalone |
| `discussion_section.docx` | 5 Discussion |
| `objectives_paragraph.docx` | 5.1 Objectives, condensed |
| `implications_section.docx` | 5.2 Implications, condensed |
| `limitations_paragraph.docx` | 5.3 Limitations, condensed |
| `appendix_b.docx` | Appendix B, alternative gap profile |
| `references.docx` | Reference list |
| `cover_letter.docx` | Submission cover letter |

Author names, institution and date are placeholders in `cover_letter.docx` and
`LICENSE`. Run `scripts/check_before_publish.sh` to locate them.
