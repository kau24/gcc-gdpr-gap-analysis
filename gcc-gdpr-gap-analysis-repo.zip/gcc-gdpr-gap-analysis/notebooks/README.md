# Notebook

`gcc_gdpr_gap_analysis.ipynb` runs the pipeline end to end, from corpus ingestion
through evaluation, figures and the final report.

Open in Colab with a T4 runtime. Two API keys are required as Colab secrets:
`OPENAI_API_KEY` and `TOGETHER_API_KEY`. Set `DATA_ROOT` to the directory holding the
corpus table and the GDPR PDF.

Sections 1 to 8 establish the environment and load checkpoints. Sections 9 to 15 issue
model calls. Section 16 onward computes every reported metric locally and requires no
API access.

See `docs/REPRODUCE.md`.
