# System dependencies

Required outside pip, for PDF ingestion:

```bash
apt-get install -y poppler-utils tesseract-ocr tesseract-ocr-ara
```

`poppler-utils` provides `pdftotext`. `tesseract-ocr-ara` is required for the Arabic
dual-source merge; without it, extraction falls back to the embedded text layer alone
and Arabic ligature errors are not repaired.

The notebook probes for each binary and reports which extraction path is available.
