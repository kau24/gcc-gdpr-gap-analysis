# Reproduction guide

## Requirements

A Colab Pro+ runtime with a T4 GPU, or an equivalent machine with CUDA. The GPU is
used only for sentence embeddings; both language models are called through APIs.

Two keys must be available as Colab secrets or environment variables:

```
OPENAI_API_KEY      # Solver
TOGETHER_API_KEY    # Critic
```

## Full reproduction

Open `notebooks/gcc_gdpr_gap_analysis.ipynb` and run top to bottom. Set `DATA_ROOT` to
the directory containing the corpus table and the GDPR PDF.

Expected cost is approximately 14,600 model calls. Runtime varies from about 11 seconds
per record on the main run to about 290 seconds on the mutation suite, where query
expansion runs to the ceiling because mutated provisions no longer match the original
query.

## Recomputing metrics only

No model calls are required to reproduce any reported figure. Run sections 1 to 8 to
establish the environment and load the checkpoints, then section 16 onward. All
evaluation metrics, figures and the final report are computed locally from the
artefacts in `results/`.

## Resumption

Every stage writes an append-only JSONL checkpoint keyed by record identifier.
Re-running any cell skips completed work. An interrupted run resumes where it stopped.

Records that failed are retained in the checkpoint with a null label; `purge_failures`
clears them so a retry re-runs those records rather than treating them as complete.

## Determinism

The main run uses temperature 0 with a fixed seed. Where the API rejects temperature
control, the parameter is omitted and this is recorded in the trace. Routing between
components is a state machine in code and does not vary between runs.

The stability replicates use temperature 0.7 deliberately: at temperature 0 the
reliability coefficient would measure the sampler being disabled rather than the
stability of the decision procedure.

## Configuration

| Parameter | Value |
|---|---|
| Retrieval depth | 12 candidates per jurisdiction |
| Query-expansion ceiling | 3 rounds |
| Sufficiency threshold | 0.15 marginal novelty |
| Critic retry bound | 2 cycles |
| Encoder | `paraphrase-multilingual-mpnet-base-v2` |
| Seed | 20260801 |

The full configuration is hashed into `results/metrics/manifest.json` at run time.
