# Evaluation protocol

No expert-annotated reference set exists for statutory gap analysis in any
jurisdiction. The protocol below obtains precision, recall and safety figures without
one.

## 1. Constructed oracles

Provisions for which the system identified a counterpart are perturbed in ways whose
correct verdict follows from the perturbation.

| Perturbation | Required verdict | Tests |
|---|---|---|
| Delete the provision | C5 | Absence detection |
| Reinsert paraphrased, no shared content word | C1 | Functional-equivalence matching |
| Swap the modal operator | C3 | Deontic sensitivity |
| Narrow or broaden the addressee class | C4 | Scope sensitivity |
| Delete the temporal element and exception | C2 | Slot-level resolution |

The paraphrase condition is decisive: a system matching on wording cannot recover a
counterpart rewritten to share no content word with the original.

**Anchor selection.** Mutations are seeded on provisions the system located. A mutation
determines a required verdict only if the mutated provision is reachable by retrieval;
seeding on an unreachable provision would confound failure to detect the perturbation
with failure to locate it. The construction therefore measures discrimination rather
than recall, and recovery rates are upper bounds.

## 2. Distractor injection

Requirement units are paired with provisions retrieved for unrelated requirements, so
absence is correct by construction and any assertion of coverage is unsupported.
Retrieval is restricted to the permitted subset.

## 3. Metamorphic relations

Three invariance relations, each requiring the verdict to be unchanged under a
transformation carrying no legal content: article renumbering, jurisdiction-name
masking, and permutation of candidate presentation order.

Article numbers appear only as candidate labels and never within the provision text
adjudicated, so the renumbering relation functions as a control and bounds the
run-to-run variability common to all three.

## 4. Reliability

Krippendorff's alpha across replicate runs at temperature 0.7. The label scheme is not
ordinal: C1 and C2 form a decreasing-coverage spine while C3, C4 and C5 are typed
divergences off that axis. The difference function assigns small distances within the
spine, larger distances between spine and divergence, and treats the divergence classes
as mutually nominal.

## 5. Grounding

String-level verification requiring no judgement: whether a cited article exists among
the selected provisions, whether the quoted span occurs within it, and whether a
modality claim is supported by a deontic operator in the cited text.

## 6. Baseline and ablation

An embedding-similarity baseline with fixed thresholds, scored against the constructed
oracles and compared to the system by adjusted Rand index. Five configurations —
full, no sufficiency check, no strategy selection, no Critic, single-agent — over a
shared record sample.

## Leakage control

The reference comparison documents quote both the GDPR and the target statutes
verbatim, so raw textual overlap with an agent prompt is not evidence of leakage. The
guard fingerprints only n-grams unique to those sources' comparative findings, obtained
by subtracting every n-gram occurring in a primary corpus, and restricted to sentences
carrying a comparative verdict. Each outgoing prompt is screened; a match raises an
exception rather than a warning.
