# Data dictionary

Every artefact produced by the pipeline, with its provenance and role.

## data/corpus/

| File | Description |
|---|---|
| `corpus.jsonl` | 427 articles: 326 GCC statutory articles across twelve instruments, 101 GDPR articles. One record per article with jurisdiction, source instrument, article number and text. |
| `extraction_quality.jsonl` | Per-source ingestion record: article count, extraction mode, token alignment rate for the Arabic dual-source merge. |
| `file_map.csv` | Classification of each source file as statute, GDPR reference, or reference knowledge base. |
| `ALL_Annt-26.xlsx` | Curated bilingual statute table, schema `(article_number, country, source_document, content)`. The primary target-corpus source. |

**Provenance.** GCC statutes are public legislative texts, transcribed and verified by
the authors. The GDPR is Regulation (EU) 2016/679 as published in the Official Journal.

## data/instrument/

| File | Description |
|---|---|
| `requirement_units.json` | 264 requirement units in the eight-slot frame, frozen with the configuration hash under which they were produced. |
| `requirement_units_core.json` | Pruned set after deduplication and per-article capping. |
| `requirement_units_transposable.json` | 171 units surviving transposability screening. **The instrument used for all reported results.** |
| `transposability_screening.json` | Screening rule, article ranges, and the full excluded set with propositions. |
| `_ru_raw.jsonl` | Raw per-article decomposition output, before assembly. |

## data/reference_kb/

| File | Description |
|---|---|
| `reference_raw.json` | Parsed text of the reference comparison documents, retained so the leakage guard is reproducible. |
| `guard_selftest.json` | Leakage-guard self-test result: fingerprint count, threshold, pass/block outcomes. |
| `labeling_functions.jsonl` | Weak labels extracted from the reference documents by distant supervision. |
| `SOURCES.md` | Citations and URLs for the reference documents, which are not redistributed. |

## data/index/

| File | Description |
|---|---|
| `index.faiss` | Inner-product index over the statute corpus. |
| `index_meta.parquet` | Row-aligned metadata: provision id, jurisdiction, article, text. |
| `vecs.npy` | Raw embedding matrix. |

## results/records/

| File | Description |
|---|---|
| `main.jsonl` | The main run: 1,584 records before screening. Append-only checkpoint. |
| `main_transposable.json` | The 1,026 records on the transposable instrument. **Primary results file.** |
| `main_records.csv` | Flat CSV of the same, for inspection. |
| `stability.jsonl` | Three replicate runs at temperature 0.7 over a 198-item sample. |
| `*.bak`, `*.parquet` | Backups and columnar exports. |

**Record schema.** Each record carries `ru_id`, `jurisdiction`, `label`,
`slot_verdicts` (eight entries with verdict, basis, span and citation),
`candidates_selected`, `candidates_excluded` with reasons, `confidence`,
`holistic_label`, `sufficiency_curve`, `n_revisions`, `n_candidates`, `n_llm_calls`,
`latency_s`, and `recovered_from_trace`.

## results/perturbations/

| File | Description |
|---|---|
| `mutations.jsonl` | 148 constructed mutations with the required verdict for each. |
| `mutation_runs.jsonl` | System output on each mutated corpus variant. |
| `mutation_runs_full.json` | Same, with full record detail. |
| `negative_controls.jsonl` | 195 constructed non-correspondences. |
| `metamorphic.jsonl` | Three invariance relations, 22 records each. |

## results/ablation/

| File | Description |
|---|---|
| `ablation.jsonl` | Five configurations over 120 shared records (480 total). |
| `ablation_mutations.jsonl` | Mutation recovery under each configuration. |

## results/metrics/

| File | Description |
|---|---|
| `metrics.json` | Consolidated metrics for every evaluation family. |
| `gap_profile_counts.csv`, `gap_profile_pct.csv` | The gap profile as counts and percentages. |
| `mutation_per_label.csv` | Per-label precision, recall, F1 and F2 on the oracle set. |
| `metamorphic.csv` | Invariance pass rates with confidence intervals and Holm-corrected p-values. |
| `ablation.csv` | Recovery and cost per configuration. |
| `slot_diagnostic.csv` | Every slot verdict with its basis, span presence and citation presence. |

## results/traces/

| File | Description |
|---|---|
| `llm_calls.jsonl` | Every model call: role, model, tag, temperature, seed, prompt hash, output, token usage, timestamp. Approximately 52 MB. |

**Note.** The trace stores a hash of each prompt rather than the prompt text, so
statutory content is not duplicated. Outputs are stored in full.

## Files excluded from this repository

`llm_calls.jsonl.corrupt` — a truncated trace from an interrupted session,
superseded by the repaired file. The reference comparison PDFs are third-party
copyrighted works; see `data/reference_kb/SOURCES.md`.
